<footer class="mt-5 py-4">
        <div class="row container mx-auto pt-5">
          <div class="container footer-one col-lg-3 col-md-6 col-md-12">
            <!-- company logo -->
            <img class="footer-img img-fluid " src="assets/imgs/image-logo2.jpg">
          </div>


          <div class="footer-two col-lg-3 col-md-6 col-md-12">
            <h5 class="pb-2">Featured</h5>
            
            <ul class="text-uppercase">
              <li><a href="#">Menu</a></li>
              <li><a href="#">Bracelets</a></li>
              <li><a href="#">Custom Bracelets</a></li>
              <li><a href="#">new arrivals</a></li>
              <li><a href="#">Featured</a></li>
            </ul>
          </div>

          <div class="footer-two col-lg-3 col-md-6 col-md-12">
            <h5 class="pb-2" id="Contact">Contact Us</h5>
            <div>
              <h6 class="text-uppercase">Address</h6>
              <p>Quezon City</p>
            </div>
            <div>
              <h6 class="text-uppercase">Phone</h6>
              <p>+63123456789</p>
            </div>
            <div>
              <h6 class="text-uppercase">Email</h6>
              <p>13@gmail.com</p>
            </div>
          </div>

          <div class="footer-two col-lg-3 col-md-6 col-md-12">
            <h5 class="pb-2">Facebook</h5>
            <div class="row">
              <!-- Facebook img -->
              <img class="img-fluid w-25 h-100 m-2" src="assets/IMAGES/p1.jpg">
              <img class="img-fluid w-25 h-100 m-2" src="assets/IMAGES/p2.jpg">
              <img class="img-fluid w-25 h-100 m-2" src="assets/IMAGES/p3.jpg">
              <img class="img-fluid w-25 h-100 m-2" src="assets/IMAGES/p4.jpg">
              <img class="img-fluid w-25 h-100 m-2" src="assets/IMAGES/p5.png">
            </div>
          </div>
        </div>

        <div class=" copyright mt-5">
          <div class="row container mx-auto">
            <div class="container col-lg-3 col-md-5 col-md-12 mb-4 ">
              <!-- payment img -->
              <img id="footer-payment" src="assets/imgs/payment/paypal.png">
              <!-- <img id="footer-payment" src="assets/imgs/payment/gcash.jpg"> -->
            </div>
            <div class="container col-lg-4 col-md-5 col-md-12 mb-4 ">
              <p>Manu's Craft Shop @ 2024 All Right Reserved</p>
            </div>
            <div class="container col-lg-3 col-md-5 col-md-12 mb-4">
              <a href="#">
                <i class="fab fa-facebook"></i>
              </a>
              <a href="#">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="#">
                <i class="fab fa-twitter"></i>
              </a>
            </div>
            </div>


        </div>

</footer>

</div>

    
</body>
<script>
  var myVar;
  function myFuntion(){
    myVar =setTimeout(showPage, 0);
  }
  function showPage() {
    document.getElementById("myDiv").style.display = "block";
  }
</script>
<!-- bootstrap js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</html>