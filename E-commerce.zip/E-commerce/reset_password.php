<?php
session_start();
require 'server/connection.php';

if (!isset($_SESSION['user_email'])) {
    header('location: login.php?error=Session expired. Please request again.');
    exit;
}

if (isset($_POST['reset_pass'])) {
    // Email should be set from the GET parameters
    $email = isset($_POST['email']) ? $_POST['email'] : null;
    $new_password = $_POST['new_password'];
    
    if (!$email) {
        header('location: forgot_password.php?error=Email not provided.');
        exit();
    }

    $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

    // Update the password in the users table and clear the verification code
    $stmt = $conn->prepare("UPDATE users SET user_password = ?, verification_code = NULL WHERE user_email = ?");
    $stmt->bind_param("ss", $hashedPassword, $email);

    if ($stmt->execute()) {
        header('location: login.php?message_update=Password has been reset successfully, please Log In');
        exit();
    } else {
        header('location: reset_password.php?error=Could not reset password.');
        exit();
    }
}
?>



<!-- Nav bar -->
<?php include('header.php') ?>

<!-- animate to show the content from the bottom -->
<div style="display: none;" id="myDiv" class="animate-bottom">

<section class="my-4 py-4">
        <div class="container text-center mt-4 py-4">
            <div>
                <h2 class="form-weight-bold">Find Your Account</h2>
                <hr class="mx-auto">
            </div>

            <div class="mx-auto container mb-5">

                <!-- HTML form for resetting the password -->
                <form id="login-form" action="reset_password.php" method="POST">
                
                    <div class="form-group mb-3">
                    <?php if(isset($_GET['error'])) {echo $_GET['error']; }  ?>
                        <input type="hidden" name="email"  value="<?php if(isset($_GET['email'])) {echo $_GET['email']; } ?>">
                        <label for="new_password">New Password:</label>
                        <input class="form-control" type="password" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <a id="Cancel" href="login.php" class="btn btn-secondary">Cancel</a>
                        <button id="buttons" class="btn" name="reset_pass" type="submit">Reset Password</button>
                    </div>

                </form>

            </div>
        </div>

     </section>


<!-- footer -->
<?php include('footer.php'); ?>